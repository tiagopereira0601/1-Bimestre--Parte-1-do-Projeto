const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3001;
const DB_PATH = path.join(__dirname, 'db.json');

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb' }));

// Função para ler o arquivo db.json
function lerDB() {
  try {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return { livros: [], emprestimos: [] };
  }
}

// Função para salvar no arquivo db.json
function salvarDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// GET - Listar todos os livros
app.get('/livros', (req, res) => {
  try {
    const db = lerDB();
    res.json(db.livros);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao ler livros' });
  }
});

// POST - Salvar novo livro
app.post('/livros', (req, res) => {
  try {
    const { titulo, autor, sinopse, capa, emprestado } = req.body;

    // Validação
    if (!titulo || !autor) {
      return res.status(400).json({ error: 'Título e autor são obrigatórios' });
    }

    const db = lerDB();
    
    // Validar se já existe um livro com o mesmo título
    if (db.livros.some(l => l.titulo.toLowerCase() === titulo.toLowerCase())) {
      return res.status(409).json({ error: 'Já existe um livro com este título' });
    }
    
    // Validar se já existe um livro com a mesma capa
    if (capa && db.livros.some(l => l.capa === capa)) {
      return res.status(409).json({ error: 'Esta capa já está cadastrada para outro livro' });
    }

    const novoLivro = {
      id: Date.now(),
      titulo,
      autor,
      sinopse: sinopse || '',
      capa: capa || '',
      emprestado: emprestado || false,
      dataCadastro: new Date().toISOString()
    };

    db.livros.push(novoLivro);
    salvarDB(db);

    res.status(201).json({ success: true, livro: novoLivro });
  } catch (error) {
    console.error('Erro ao salvar livro:', error);
    res.status(500).json({ error: 'Erro ao salvar livro' });
  }
});

// GET - Buscar livro por ID
app.get('/livros/:id', (req, res) => {
  try {
    const db = lerDB();
    const livro = db.livros.find(l => l.id === parseInt(req.params.id));
    
    if (!livro) {
      return res.status(404).json({ error: 'Livro não encontrado' });
    }

    res.json(livro);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar livro' });
  }
});

// DELETE - Deletar livro
app.delete('/livros/:id', (req, res) => {
  try {
    const db = lerDB();
    const livroId = parseInt(req.params.id);
    const index = db.livros.findIndex(l => l.id === livroId);

    if (index === -1) {
      return res.status(404).json({ error: 'Livro não encontrado' });
    }

    const livroRemovido = db.livros.splice(index, 1);
    
    // Remover também os empréstimos associados ao livro
    db.emprestimos = db.emprestimos.filter(e => e.livroId !== livroId);
    
    salvarDB(db);

    res.json({ success: true, livro: livroRemovido[0] });
  } catch (error) {
    console.error('Erro ao deletar livro:', error);
    res.status(500).json({ error: 'Erro ao deletar livro' });
  }
});

// GET - Listar todos os empréstimos
app.get('/emprestimos', (req, res) => {
  try {
    const db = lerDB();
    const emprestimosComDetalhes = db.emprestimos.map(emp => {
      const livro = db.livros.find(l => l.id === emp.livroId);
      return {
        ...emp,
        capa: livro?.capa || ''
      };
    });
    res.json(emprestimosComDetalhes);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao ler empréstimos' });
  }
});

// POST - Criar novo empréstimo
app.post('/emprestimos', (req, res) => {
  try {
    const { livroId, titulo, autor, capa, status } = req.body;

    if (!livroId || !titulo || !autor) {
      return res.status(400).json({ error: 'livroId, titulo e autor são obrigatórios' });
    }

    const db = lerDB();
    const novoEmprestimo = {
      id: Date.now(),
      livroId,
      titulo,
      autor,
      capa: capa || '',
      status: status || 'emprestado',
      dataEmprestimo: new Date().toISOString(),
      rating: 0
    };

    db.emprestimos.push(novoEmprestimo);
    salvarDB(db);

    res.status(201).json({ success: true, emprestimo: novoEmprestimo });
  } catch (error) {
    console.error('Erro ao criar empréstimo:', error);
    res.status(500).json({ error: 'Erro ao criar empréstimo' });
  }
});

// GET - Buscar empréstimo por ID
app.get('/emprestimos/:id', (req, res) => {
  try {
    const db = lerDB();
    const emprestimo = db.emprestimos.find(e => e.id === parseInt(req.params.id));

    if (!emprestimo) {
      return res.status(404).json({ error: 'Empréstimo não encontrado' });
    }

    res.json(emprestimo);
  } catch (error) {
    res.status(500).json({ error: 'Erro ao buscar empréstimo' });
  }
});

// PATCH - Atualizar empréstimo
app.patch('/emprestimos/:id', (req, res) => {
  try {
    const db = lerDB();
    const emprestimo = db.emprestimos.find(e => e.id === parseInt(req.params.id));

    if (!emprestimo) {
      return res.status(404).json({ error: 'Empréstimo não encontrado' });
    }

    const { status, rating } = req.body;
    if (status !== undefined) emprestimo.status = status;
    if (rating !== undefined) emprestimo.rating = rating;

    salvarDB(db);
    res.json({ success: true, emprestimo });
  } catch (error) {
    console.error('Erro ao atualizar empréstimo:', error);
    res.status(500).json({ error: 'Erro ao atualizar empréstimo' });
  }
});

// DELETE - Deletar empréstimo
app.delete('/emprestimos/:id', (req, res) => {
  try {
    const db = lerDB();
    const index = db.emprestimos.findIndex(e => e.id === parseInt(req.params.id));

    if (index === -1) {
      return res.status(404).json({ error: 'Empréstimo não encontrado' });
    }

    const emprestimoRemovido = db.emprestimos.splice(index, 1);
    salvarDB(db);

    res.json({ success: true, emprestimo: emprestimoRemovido[0] });
  } catch (error) {
    res.status(500).json({ error: 'Erro ao deletar empréstimo' });
  }
});

// PATCH - Atualizar livro
app.patch('/livros/:id', (req, res) => {
  try {
    const db = lerDB();
    const livroId = parseInt(req.params.id);
    const livro = db.livros.find(l => l.id === livroId);

    if (!livro) {
      return res.status(404).json({ error: 'Livro não encontrado' });
    }

    const { titulo, autor, sinopse, capa, emprestado } = req.body;
    
    // Validar se o novo título já existe em outro livro
    if (titulo !== undefined && titulo !== livro.titulo) {
      if (db.livros.some(l => l.id !== livroId && l.titulo.toLowerCase() === titulo.toLowerCase())) {
        return res.status(409).json({ error: 'Já existe um livro com este título' });
      }
    }
    
    // Validar se a nova capa já existe em outro livro
    if (capa !== undefined && capa !== livro.capa && capa) {
      if (db.livros.some(l => l.id !== livroId && l.capa === capa)) {
        return res.status(409).json({ error: 'Esta capa já está cadastrada para outro livro' });
      }
    }
    
    if (titulo !== undefined) livro.titulo = titulo;
    if (autor !== undefined) livro.autor = autor;
    if (sinopse !== undefined) livro.sinopse = sinopse;
    if (capa !== undefined) livro.capa = capa;
    if (emprestado !== undefined) livro.emprestado = emprestado;

    salvarDB(db);
    res.json({ success: true, livro });
  } catch (error) {
    console.error('Erro ao atualizar livro:', error);
    res.status(500).json({ error: 'Erro ao atualizar livro' });
  }
});

// Iniciar servidor
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
  console.log(`Salvando dados em ${DB_PATH}`);
});
